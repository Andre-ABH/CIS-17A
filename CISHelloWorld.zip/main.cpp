/* 
 * File:   main.cpp
 * Author: Andre Abou-Habib
 * Date: August 28th, 2024
 * Purpose: "Hello World" program
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {

    cout << "Hello world!";
    
    return 0;
}

